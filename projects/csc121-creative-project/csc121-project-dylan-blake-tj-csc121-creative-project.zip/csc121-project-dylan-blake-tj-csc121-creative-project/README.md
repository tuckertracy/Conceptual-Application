# csc121-project-dylan-blake-tj
A group project made by Dylan Bloch, Blake Cambell, Tucker Tracy. 
The game is a basketball game with a countdown. The challenege is to see how far you can get within your limited time.
As you progress through the levels you get taken on a wonderous tour of the universe.
